import React, { useEffect, useState } from 'react';
import { collection, query, onSnapshot, deleteDoc, doc } from '../firebase';
import { auth, firestore } from '../firebase';
import { useNavigate } from 'react-router-dom'; // Add useNavigate for routing
import defaultProfilePic from '../assets/images/default.jpg'; // Adjust the path as needed

const Challenges = () => {
    const [challenges, setChallenges] = useState([]);
    const navigate = useNavigate(); // Initialize useNavigate

    useEffect(() => {
        const challengesCollectionRef = collection(firestore, 'challenges');
        const q = query(challengesCollectionRef);

        const unsubscribe = onSnapshot(q, (snapshot) => {
            const challengesData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id }));
            setChallenges(challengesData.filter(challenge => new Date(challenge.availableTo) >= new Date()));
        });

        return unsubscribe; // Cleanup subscription on unmount
    }, []);

    const handleAccept = (challenge) => {
        // Redirect to Messages.js, passing challenge creator's userId
        navigate('/messages', { state: { recipientId: challenge.userId } });
    };

    const handleDelete = async (id) => {
        try {
            await deleteDoc(doc(firestore, 'challenges', id));
            alert('Challenge deleted successfully');
        } catch (error) {
            console.error('Error deleting challenge:', error.message);
        }
    };

    return (
        <div className="container mx-auto p-4">
            <h2 className="text-2xl font-bold mb-4 text-white">Challenges</h2>
            <div className="space-y-4">
                {challenges.map(challenge => (
                    <ChallengeItem
                        key={challenge.id}
                        challenge={challenge}
                        onAccept={handleAccept}
                        onDelete={handleDelete}
                    />
                ))}
            </div>
        </div>
    );
};

const ChallengeItem = ({ challenge, onAccept, onDelete }) => {
    const [profilePicture, setProfilePicture] = useState(defaultProfilePic);

    return (
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg text-white flex justify-between items-center">
            <div className="flex items-center space-x-6">
                <img
                    src={profilePicture}
                    alt="Profile"
                    className="w-16 h-16 rounded-full border-2 border-white"
                />
                <div>
                    <p className="text-lg font-semibold">{challenge.username}</p>
                    <p className="text-md text-gray-400">
                        {new Date(challenge.createdAt.seconds * 1000).toLocaleDateString()}
                    </p>
                </div>
            </div>
            <div className="flex-1 ml-8 text-lg">
                <p>Sport: {challenge.sport}</p>
                <p>From: {new Date(challenge.availableFrom).toLocaleDateString()}</p>
                <p>To: {new Date(challenge.availableTo).toLocaleDateString()}</p>
                <p>Timings: {challenge.timing}</p>
            </div>
            <div className="flex space-x-6">
                {auth.currentUser.uid !== challenge.userId && (
                    <button
                        onClick={() => onAccept(challenge)}
                        className="bg-green-500 text-white px-6 py-3 rounded-lg hover:bg-green-600 text-lg"
                    >
                        Accept
                    </button>
                )}
                {auth.currentUser.uid === challenge.userId && (
                    <button
                        onClick={() => onDelete(challenge.id)}
                        className="bg-red-500 text-white px-6 py-3 rounded-lg hover:bg-red-600 text-lg"
                    >
                        Delete
                    </button>
                )}
            </div>
        </div>
    );
};

export default Challenges;
