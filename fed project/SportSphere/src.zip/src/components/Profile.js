// Profile.js
import React, { useState, useEffect } from 'react';
import { auth, firestore, signOut, updateDoc, doc, getDoc, collection, addDoc, query, where, getDocs, setDoc  } from '../firebase';
import { useNavigate } from 'react-router-dom';
import { updateProfile } from 'firebase/auth'; // For updating profile info in Firebase Auth
import defaultProfilePic from '../assets/images/default.jpg'; // Adjust the path as needed





const Profile = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState({});
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [availableFrom, setAvailableFrom] = useState('');
  const [availableTo, setAvailableTo] = useState('');
  const [timing, setTiming] = useState('');
  const [sport, setSport] = useState('');
  const [profilePicture, setProfilePicture] = useState(defaultProfilePic);
  const [newProfilePicture, setNewProfilePicture] = useState(null); // New state for selected image

  useEffect(() => {
    const fetchUserData = async () => {
      const user = auth.currentUser;
      if (user) {
        const docRef = doc(firestore, 'users', user.uid);
        console.log(docRef)
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setUserData(data);
          setUsername(data.username || '');
          setEmail(data.email || '');
          setProfilePicture(data.profilePicture);
          console.log(userData, username, email, profilePicture)
        }
        else console.log("there is no docSnap lol");
      }
      else console.log("there is no user lol");
    };

    fetchUserData();
  }, []);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error.message);
    }
  };

  const handleProfileImageClick = () => {
    document.getElementById('profileImageInput').click();
  };

  const handleProfileImageChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      // console.log('file', file);
      // console.log('url apparently: ', URL.createObjectURL(file));
      setNewProfilePicture("../assets/images/"+file.name);
      // setProfilePicture(URL.createObjectURL(file)); // Preview the selected image
    }
    else setNewProfilePicture({defaultProfilePic})
  };

  const handleUpdateProfile = async (e) => {
    e.preventDefault();
    try {
      const user = auth.currentUser;
      if (user) {
        // Check for existing username and email
        const usersCollectionRef = collection(firestore, 'users');
        const queryUsername = query(usersCollectionRef, where("username", "==", username));
        const queryEmail = query(usersCollectionRef, where("email", "==", email));
        
        const usernameSnapshot = await getDocs(queryUsername);
        const emailSnapshot = await getDocs(queryEmail);
        
        if (usernameSnapshot.docs.length > 0 && usernameSnapshot.docs[0].id !== user.uid) {
          alert('Username is already taken by another user.');
          return;
        }
        
        if (emailSnapshot.docs.length > 0 && emailSnapshot.docs[0].id !== user.uid) {
          alert('Email is already associated with another user.');
          return;
        }
        
        // Proceed with update if no duplicates
        const docRef = doc(firestore, 'users', user.uid);
        let updatedProfilePicture = profilePicture;
  
        if (newProfilePicture) {
          updatedProfilePicture = newProfilePicture;
        }
  
        await updateDoc(docRef, {
          username: username,
          email: email,
          profilePicture: updatedProfilePicture,
        });
  
        // Update profile in Firebase Auth
        await updateProfile(user, {
          displayName: username,
          photoURL: updatedProfilePicture,
        });
  
        alert('Profile updated successfully!');
      }
    } catch (error) {
      console.error('Error updating profile:', error.message);
    }
  };


const handleCreateChallenge = async (e) => {
    e.preventDefault();

    if (!sport || !availableFrom || !availableTo || !timing) {
        alert('Please fill out all fields before posting a challenge.');
        return;
    }

    try {
        const user = auth.currentUser;
        if (user) {
            const challenge = {
                userId: user.uid,
                username: userData.username,  
                sport,
                availableFrom,
                availableTo,
                timing,
                createdAt: new Date(),
            };

            // Use setDoc to ensure the document ID is the same as the user ID
            const challengeDocRef = doc(firestore, 'challenges', user.uid);
            await setDoc(challengeDocRef, challenge);

            alert('Challenge posted successfully!');
            navigate('/challenges');
        }
    } catch (error) {
        console.error('Error creating challenge:', error.message);
    }
};


  return (
    <div className="flex flex-col justify-start items-start h-screen bg-primaryBlack text-primaryWhite px-8 pt-20">
      
      {/* Profile Section with White Background */}
      <div className="w-full mb-8 bg-primaryWhite text-primaryBlack p-6 rounded">

        <h1 className="text-3xl font-bold mb-6">Hi, {username}</h1>

        {/* Profile Picture */}
        <div className="mb-6">
          <img 
            src={defaultProfilePic} 
            alt="Profile" 
            className="w-24 h-24 rounded-full mb-4 cursor-pointer"
            onClick={handleProfileImageClick}
          />
          <input 
            type="file" 
            id="profileImageInput" 
            accept="sportify/public/*" 
            style={{ display: 'none' }} 
            onChange={handleProfileImageChange} 
          />
        </div>

        {/* Update Profile Form */}
        <form onSubmit={handleUpdateProfile} className="w-full mb-8">
          <fieldset className="border-b border-gray-600 pb-4 mb-4">
            <legend className="text-xl font-semibold mb-2">Account Info</legend>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Username:</label>
              <input 
                type="text" 
                value={username} 
                onChange={(e) => setUsername(e.target.value)} 
                className="w-full p-2 border-b border-black bg-primaryWhite text-primaryBlack focus:outline-none" 
                required 
              />
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-1">Email:</label>
              <input 
                type="email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                className="w-full p-2 border-b border-black bg-primaryWhite text-primaryBlack focus:outline-none" 
                required 
              />
            </div>

            <button type="submit" className="bg-primaryBlack text-primaryWhite px-4 py-2 rounded mt-4">
              Update Profile
            </button>
          </fieldset>
        </form>
      
      </div>

      {/* Create Challenge Form - No Style Changes */}
      <form onSubmit={handleCreateChallenge} className="w-full">
        <fieldset className="border-b border-gray-600 pb-4 mb-4">
          <legend className="text-xl font-semibold mb-2">Create New Challenge</legend>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">Sport:</label>
            <input 
              type="text" 
              value={sport} 
              onChange={(e) => setSport(e.target.value)} 
              className="w-full p-2 border-b border-white bg-primaryBlack text-primaryWhite focus:outline-none" 
              required 
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">Available from:</label>
            <input 
              type="date" 
              value={availableFrom} 
              onChange={(e) => setAvailableFrom(e.target.value)} 
              className="w-full p-2 border-b border-white bg-primaryBlack text-primaryWhite focus:outline-none" 
              required 
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">To:</label>
            <input 
              type="date" 
              value={availableTo} 
              onChange={(e) => setAvailableTo(e.target.value)} 
              className="w-full p-2 border-b border-white bg-primaryBlack text-primaryWhite focus:outline-none" 
              required 
            />
          </div>

          <div className="mb-4">
            <label className="block text-sm font-medium mb-1">Timings:</label>
            <select 
              value={timing} 
              onChange={(e) => setTiming(e.target.value)} 
              className="w-full p-2 border-b border-white bg-primaryBlack text-primaryWhite focus:outline-none" 
              required 
            >
              <option value="">Select...</option>
              <option value="Morning">Morning</option>
              <option value="Evening">Evening</option>
            </select>
          </div>

          <button type="submit" className="bg-primaryWhite text-primaryBlack px-4 py-2 rounded mt-4">
            Post Challenge
          </button>
        </fieldset>
      </form>

      {/* Forgot Password Link */}
      <div className="mt-4">
        <a href="/forgot-password" className="text-blue-500 underline">
          Forgot your password? Reset it here.
        </a>
      </div>

      {/* Logout Button */}
      <button onClick={handleLogout} className="bg-red-600 text-primaryWhite px-4 py-2 rounded mt-6">
        Logout
      </button>
    </div>
  );
};

export default Profile;
