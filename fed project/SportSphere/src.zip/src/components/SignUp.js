import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth, firestore, collection, doc, setDoc, query, where, getDocs } from '../firebase';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import defaultProfilePic from '../assets/images/default.jpg'; // Adjust the path as needed




const SignUp = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSignUp = async (e) => {
    e.preventDefault();
    try {
      // Check if username already exists
      const q = query(collection(firestore, 'users'), where('username', '==', username));
      const querySnapshot = await getDocs(q);
      if (!querySnapshot.empty) {
        setError('Username already taken. Please choose another.');
        return;
      }

      // Create user
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Add user to Firestore with user.uid as document ID
      await setDoc(doc(firestore, 'users', user.uid), {
        uid: user.uid,
        email: user.email,
        username: username,
        profilePicture: defaultProfilePic
      });

      navigate('/login');
    } catch (error) {
      // Handle specific Firebase error codes
      if (error.code === 'auth/email-already-in-use') {
        setError('The email address is already in use by another account.');
      } else if (error.code === 'auth/weak-password') {
        setError('The password is too weak. Please choose a stronger password.');
      } else if (error.code === 'auth/invalid-email') {
        setError('The email address is not valid. Please enter a valid email address.');
      } else {
        setError('Error creating account. Please try again.');
      }
      console.error('Error creating account:', error.message);
    }
  };

  return (
    <div className="flex justify-center items-center h-screen bg-primaryWhite text-primaryBlack">
      <form onSubmit={handleSignUp} className="bg-primaryWhite text-primaryBlack p-8 rounded-lg">
        <h2 className="text-2xl font-bold mb-6">Get Burdurned With Glorious Purpose!</h2>
        
        {error && <div className="bg-red-200 text-red-700 p-2 rounded mb-4">{error}</div>}
        
        <div className="mb-4">
          <label htmlFor="username" className="block text-sm font-medium mb-1">Username:</label>
          <input
            type="text"
            id="username"
            className="w-full p-2 border border-black rounded"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        
        <div className="mb-4">
          <label htmlFor="email" className="block text-sm font-medium mb-1">Email:</label>
          <input
            type="email"
            id="email"
            className="w-full p-2 border border-black rounded"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        
        <div className="mb-6">
          <label htmlFor="password" className="block text-sm font-medium mb-1">Password:</label>
          <input
            type="password"
            id="password"
            className="w-full p-2 border border-black rounded"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>
        
        <button type="submit" className="bg-primaryBlack text-primaryWhite px-4 py-2 rounded hover:bg-gray-800">
          Sign Up
        </button>
        
        <div className="mt-4 text-center">
          <p>
            Already have an account? 
            <a href="/login" className="text-blue-500 underline ml-1">Log In</a>
          </p>
        </div>
      </form>
    </div>
  );
};

export default SignUp;
