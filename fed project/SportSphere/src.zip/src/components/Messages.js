import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { collection, addDoc, query, where, onSnapshot, getDoc, doc } from 'firebase/firestore';
import { auth, firestore } from '../firebase';

export default function Messages() {
    const location = useLocation();
    const recipientId = location.state.recipientId; // Retrieve recipientId from state
    const [message, setMessage] = useState('');
    const [messages, setMessages] = useState([]);
    const [recipientName, setRecipientName] = useState('');
    const [users, setUsers] = useState({}); // To store user data for all participants

    useEffect(() => {
        // Fetch recipient name from 'users' collection
        const fetchRecipientName = async () => {
            const recipientDoc = await getDoc(doc(firestore, 'users', recipientId));
            if (recipientDoc.exists()) {
                setRecipientName(recipientDoc.data().username); // Adjust 'username' according to your user structure
            }
        };

        fetchRecipientName();
    }, [recipientId]);

    useEffect(() => {
        const messagesCollectionRef = collection(firestore, 'messages');
        const q = query(messagesCollectionRef, where('participants', 'array-contains', auth.currentUser.uid));

        const unsubscribe = onSnapshot(q, async (snapshot) => {
            const messagesData = snapshot.docs.map(doc => doc.data());
            setMessages(messagesData);

            // Fetch user details (for both sender and recipient) to display their names
            const userIds = Array.from(new Set(messagesData.flatMap(msg => [msg.senderId, msg.recipientId])));
            const userDataPromises = userIds.map(async (userId) => {
                const userDoc = await getDoc(doc(firestore, 'users', userId));
                return { userId, username: userDoc.exists() ? userDoc.data().username : 'Unknown' };
            });

            const userDataArray = await Promise.all(userDataPromises);
            const userDataMap = userDataArray.reduce((acc, user) => {
                acc[user.userId] = user.username;
                return acc;
            }, {});

            setUsers(userDataMap);
        });

        return unsubscribe;
    }, []);

    const handleSendMessage = async () => {
        if (message.trim()) {
            await addDoc(collection(firestore, 'messages'), {
                text: message,
                senderId: auth.currentUser.uid,
                recipientId: recipientId,
                participants: [auth.currentUser.uid, recipientId],
                timestamp: new Date(),
            });
            setMessage(''); // Clear the input field after sending
        }
    };

    return (
        <div className="container mx-auto p-4">
            <h2 className="text-2xl font-bold mb-4 text-white">Messages with {recipientName}</h2>
            <div className="bg-gray-800 p-6 rounded-lg shadow-lg text-white">
                <div className="space-y-4 mb-4">
                    {messages.map((msg, index) => (
                        <div key={index} className="p-3 rounded bg-gray-700">
                            <p>
                                {users[msg.senderId] === auth.currentUser.uid ? 'You' : users[msg.senderId]}: {msg.text}
                            </p>
                        </div>
                    ))}
                </div>
                <input
                    type="text"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Type your message..."
                    className="w-full p-3 rounded-lg bg-gray-700 text-white"
                />
                <button
                    onClick={handleSendMessage}
                    className="mt-3 w-full bg-green-500 text-white px-6 py-3 rounded-lg hover:bg-green-600"
                >
                    Send
                </button>
            </div>
        </div>
    );
}
